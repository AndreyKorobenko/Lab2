
rootProject.name = "laba2"

