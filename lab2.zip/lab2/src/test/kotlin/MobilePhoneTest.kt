import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class MobilePhoneTest {

    var mobile = MobilePhone("80001002323")
    @Test
    fun addNewContact() {
        var contact = Contact("Name", "Phone")
        mobile.addNewContact(contact)
        assertTrue(contact == mobile.contacts[0])
    }

    @Test
    fun updateContact() {
        var contact = Contact("Name", "Phone")
        mobile.addNewContact(contact)
        var newContact = Contact("NewName", "NewPhone")
        mobile.updateContact(contact, newContact)
        assertTrue(newContact == mobile.contacts[0])
    }

    @Test
    fun removeContact() {
        var contact = Contact("Name", "Phone")
        mobile.addNewContact(contact)
        mobile.removeContact(contact)
        assertTrue(mobile.contacts.size == 0)
    }
}