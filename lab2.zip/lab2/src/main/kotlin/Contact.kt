data class Contact(var name: String, var phone: String){

}
